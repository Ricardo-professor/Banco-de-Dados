--Atualização 1

UPDATE produtos SET nome_produto = 'Teclado sem Fio'
WHERE id = 3;

--Atualização 2

UPDATE produtos SET valor_venda = 110.00
WHERE id = 4;

--Atualização 3

UPDATE produtos SET valor_venda = valor_venda * 1.10;