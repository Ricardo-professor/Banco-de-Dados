-- Registro na tabela de documentos
INSERT INTO exercicio.documentos (numero_documento, data_documento, valor_total, valor_liquido)

VALUES
	('DOC001', '2023-08-01', 500.00, 450.00),
	('DOC002', '2023-08-02', 750.00, 700.00),
	('DOC003', '2023-08-03', 1000.00, 950.00),
	('DOC004', '2023-08-03', 300.00, 270.00),
	('DOC005', '2023-08-03', 1200.00, 1100.00);

-- Registro na tabela de produtos
INSERT INTO exercicio.produtos (cod_produto, nome_produto, valor_custo, valor_venda)

VALUES
	('P001', 'Headset', 50.00, 120.00),
	('P002', 'Webcam', 30.00, 90.00),
	('P003', 'Teclado', 25.00, 80.00),
	('P004', 'Mouse', 10.00, 40.00),
	('P005', 'SSD 256 GB', 80.00, 150.00);
		
--Registro na tabela de clientes
INSERT INTO exercicio.clientes (nome_cliente, whatsapp)

VALUES
	('Felipe', '22 91111-2222'),
	('João', '22 92222-3333'),
	('Caroline', '21 93333-4444'),
	('Rafael', '24 94444-5555'),
	('Valentina', '11 95555-6666');
	
--Registro na tabela de produtos e documentos
INSERT INTO exercicio.produtos_documento (documento_id, clientes_id, produto_id, valor_unitario, valor_desconto, valor_acrescimo, valor_bruto, valor_liquido)

VALUES
	(1, 1, 1, 120.00, 10.00, 0.00, 110.00, 100.00),
	(2, 2, 2, 90.00, 5.00, 0.00, 85.00, 80.00),
	(3, 3, 3, 80.00, 0.00, 0.00, 80.00, 80.00),
	(4, 4, 4, 40.0, 5.00, 0.00, 35.00, 30.00),
	(5, 5, 5, 150.00, 0.00, 0.00, 150.00, 150.00);
	
	