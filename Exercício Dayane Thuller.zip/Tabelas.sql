-- Tabela de documentos
CREATE TABLE exercicio.documentos (
		
		id serial PRIMARY KEY,
		numero_documento VARCHAR(20) NOT NULL, 
		data_documento DATE NOT NULL,
		valor_total DOUBLE PRECISION NOT NULL,
		valor_liquido DOUBLE PRECISION NOT NULL
	);
	
-- Tabela de produtos
CREATE TABLE exercicio.produtos (
		
		id serial PRIMARY KEY,
		cod_produto VARCHAR(20) NOT NULL, 
		nome_produto VARCHAR(100) NOT NULL, 
		valor_custo DOUBLE PRECISION NOT NULL, 
		valor_venda DOUBLE PRECISION NOT NULL
	);
	
--Tabela de Clientes
CREATE TABLE exercicio.clientes (
	
		id SERIAL PRIMARY KEY,
		nome_cliente VARCHAR (100) NOT NULL,
		whatsapp VARCHAR (20) NOT NULL
	);
	
-- Tabela de Produtos do documento
CREATE TABLE exercicio.produtos_documento (

		id serial PRIMARY KEY,
		documento_id INT REFERENCES exercicio.documentos(id),
		produto_id INT REFERENCES exercicio.produtos(id),
		clientes_id INT REFERENCES exercicio.clientes(id),
		valor_unitario DOUBLE PRECISION NOT NULL,
		valor_desconto DOUBLE PRECISION NOT NULL,
		valor_acrescimo DOUBLE PRECISION NOT NULL,
		valor_bruto DOUBLE PRECISION NOT NULL,
		valor_liquido DOUBLE PRECISION NOT NULL
	);


		
