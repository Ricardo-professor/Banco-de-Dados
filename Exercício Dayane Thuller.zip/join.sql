--Consulta 1

SELECT d.numero_documento, p.nome_produto, pd.valor_unitario, pd.valor_desconto, pd.valor_acrescimo, pd.valor_bruto, pd.valor_liquido

FROM exercicio.documentos d

JOIN exercicio.produtos_documento pd on d.id = pd.documento_id
JOIN exercicio.produtos p on pd.produto_id = p.id
WHERE d.id = 1;

--Consulta 2

SELECT * FROM exercicio.produtos WHERE valor_venda > 100.00;

--Consulta 3 

SELECT d.numero_documento, c.nome_cliente, c.whatsapp, p.nome_produto, pd.valor_unitario, pd.valor_desconto, pd.valor_acrescimo, pd.valor_bruto, pd.valor_liquido

FROM exercicio.documentos d

JOIN exercicio.produtos_documento pd on d.id = pd.documento_id
JOIN exercicio.produtos p on pd.produto_id = p.id
JOIN exercicio.clientes c on pd.clientes_id = c.id
--WHERE d.id = 1;
